# ⚡ ELECTRA — Electrician Learning Platform

A mobile-first React app for electricians to study, take quizzes, and track their progress. Built with **React + Vite + Firebase**.

---

## 📱 Features

- **OTP Phone Login** — Firebase Authentication with Indian (+91) phone numbers
- **Profile Setup** — Name, qualification, experience, specialization
- **Study Hub** — 4 modules: Basic Wiring, Industrial, Testing, Safety
- **Article Reader** — In-depth articles with markdown-style formatting
- **Quiz Engine** — Timed quizzes with explanations, XP rewards, pass/fail
- **Progress Tracker** — Score trend chart, performance history
- **Dashboard** — Stats overview, recent tests, quick navigation
- **Demo Mode** — Works without real Firebase (OTP: `123456`)

---

## 🚀 Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/electra-learning-platform.git
cd electra-learning-platform
```

### 2. Install dependencies

```bash
npm install
```

### 3. Setup Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project (or use existing)
3. Enable **Authentication → Phone** sign-in method
4. Enable **Firestore Database**
5. Copy your project credentials

### 4. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and fill in your Firebase credentials:

```env
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
...
```

### 5. Run locally

```bash
npm run dev
```

App opens at `http://localhost:3000`

---

## 🏗️ Project Structure

```
electra-learning-platform/
├── public/
│   └── favicon.svg
├── src/
│   ├── main.jsx          # React entry point
│   └── App.jsx           # Main application (all components)
├── .env                  # Your Firebase credentials (NOT committed)
├── .env.example          # Template for credentials
├── .gitignore
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## 🔥 Firestore Schema

```
users/{uid}
  ├─ name, age, phone
  ├─ qualification, experience, specialization
  ├─ totalXP, level, studyStreak
  └─ completedTopics[]

testResults (subcollection under each user)
  ├─ moduleId, score, total
  ├─ pct, pass (boolean)
  └─ timestamp
```

---

## 🛠️ Tech Stack

| Tool | Version |
|------|---------|
| React | 18.x |
| Vite | 5.x |
| Firebase | 10.x |

---

## 📦 Build for Production

```bash
npm run build
```

Output goes to `/dist` — ready to deploy on Firebase Hosting, Vercel, or Netlify.

### Deploy to Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```

---

## ⚠️ Important Notes

- `.env` is in `.gitignore` — **never commit real API keys**
- Demo mode: enter any phone number → use OTP `123456`
- App is designed for mobile (max-width: 480px)

---

## 📄 License

MIT License — free to use and modify.
