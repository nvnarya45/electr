import { useState, useEffect, useRef } from "react";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  RecaptchaVerifier,
  signInWithPhoneNumber,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  collection,
  addDoc,
  getDocs,
  query,
  orderBy,
  serverTimestamp,
} from "firebase/firestore";

/* ─────────────────────────────────────────────
   FIREBASE INIT — config loaded from .env file
   See .env.example to set up your credentials
───────────────────────────────────────────── */
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};
let app, auth, db;
try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
} catch (e) {
  console.warn("Firebase init:", e.message);
}

/* ─────────────────────────────────────────────
   STATIC DATA
───────────────────────────────────────────── */
const STUDY_MODULES = [
  {
    id: "basic",
    icon: "⚡",
    title: "Basic House Wiring",
    color: "#F59E0B",
    topics: 12,
    desc: "Fundamentals of residential electrical systems, circuits & safety.",
    articles: [
      { id: "b1", title: "Understanding AC/DC Current", duration: "8 min", tag: "Basics" },
      { id: "b2", title: "Wire Gauges & Current Ratings", duration: "6 min", tag: "Wiring" },
      { id: "b3", title: "Circuit Breakers & Fuses", duration: "10 min", tag: "Safety" },
      { id: "b4", title: "Earthing & Grounding Systems", duration: "9 min", tag: "Safety" },
    ],
  },
  {
    id: "industrial",
    icon: "🏭",
    title: "Industrial Wiring",
    color: "#3B82F6",
    topics: 18,
    desc: "3-phase systems, motor connections, panel installations.",
    articles: [
      { id: "i1", title: "3-Phase Power Systems", duration: "12 min", tag: "Industrial" },
      { id: "i2", title: "Star & Delta Connections", duration: "11 min", tag: "Motors" },
      { id: "i3", title: "Panel Board Installation", duration: "14 min", tag: "Panels" },
      { id: "i4", title: "Cable Tray & Conduit Systems", duration: "8 min", tag: "Wiring" },
    ],
  },
  {
    id: "testing",
    icon: "🔬",
    title: "Testing Procedures",
    color: "#10B981",
    topics: 15,
    desc: "Hipot tests, Insulation Resistance, Megger testing & more.",
    articles: [
      { id: "t1", title: "Megger Insulation Resistance Test", duration: "13 min", tag: "Testing" },
      { id: "t2", title: "Hipot (High Potential) Testing", duration: "15 min", tag: "HV Testing" },
      { id: "t3", title: "Earth Continuity Testing", duration: "10 min", tag: "Safety" },
      { id: "t4", title: "Loop Impedance Testing", duration: "12 min", tag: "Testing" },
    ],
  },
  {
    id: "safety",
    icon: "🛡️",
    title: "Electrical Safety",
    color: "#EF4444",
    topics: 10,
    desc: "IS codes, PPE, lockout/tagout, and safety regulations.",
    articles: [
      { id: "s1", title: "IS 732 Wiring Standards", duration: "11 min", tag: "Standards" },
      { id: "s2", title: "Lockout / Tagout Procedures", duration: "9 min", tag: "Safety" },
      { id: "s3", title: "PPE for Electricians", duration: "7 min", tag: "Safety" },
      { id: "s4", title: "Arc Flash & Blast Protection", duration: "13 min", tag: "HV Safety" },
    ],
  },
];

const QUIZ_BANK = {
  basic: [
    { q: "What is the standard color for the Live wire in Indian wiring?", options: ["Red", "Black", "Green", "Yellow"], ans: 0, exp: "In Indian wiring standards (IS 732), the Live wire is Red, Neutral is Black, and Earth is Green/Yellow." },
    { q: "What device protects a circuit from overcurrent?", options: ["Voltmeter", "Circuit Breaker", "Capacitor", "Transformer"], ans: 1, exp: "A Circuit Breaker automatically interrupts current flow when it exceeds safe levels." },
    { q: "The unit of electrical resistance is:", options: ["Volt", "Ampere", "Ohm", "Watt"], ans: 2, exp: "Resistance is measured in Ohms (Ω), named after Georg Simon Ohm." },
    { q: "Ohm's Law states that V =", options: ["I + R", "I × R", "I / R", "I² × R"], ans: 1, exp: "Ohm's Law: Voltage (V) = Current (I) × Resistance (R)" },
    { q: "Which wire is NOT part of a standard single-phase supply?", options: ["Live", "Neutral", "Earth", "Phase-B"], ans: 3, exp: "Single-phase supply has Live, Neutral, and Earth. Phase-B is part of 3-phase systems." },
  ],
  testing: [
    { q: "A Megger test primarily measures:", options: ["Voltage", "Current", "Insulation Resistance", "Power Factor"], ans: 2, exp: "A Megger (insulation resistance tester) applies a high DC voltage to measure insulation resistance in MΩ." },
    { q: "The minimum acceptable insulation resistance for a domestic installation is:", options: ["0.5 MΩ", "1 MΩ", "5 MΩ", "10 MΩ"], ans: 1, exp: "IS 732 specifies a minimum IR value of 1 MΩ for domestic installations." },
    { q: "Hipot testing uses which type of voltage?", options: ["Low DC", "High AC or DC", "Low AC", "Pulsed DC only"], ans: 1, exp: "Hipot (High Potential) testing uses voltages much higher than normal operating voltage — either AC or DC — to stress-test insulation." },
    { q: "During a Megger test, what should be done with all loads?", options: ["Keep them ON", "Disconnect them", "Put on half load", "Short them"], ans: 1, exp: "All loads must be disconnected before performing an insulation resistance test to avoid damage and get accurate readings." },
    { q: "Loop impedance testing is used to verify:", options: ["Voltage stability", "Current balance", "Earth fault loop path integrity", "Power quality"], ans: 2, exp: "Loop impedance testing ensures the earth fault loop impedance is low enough for protective devices to operate within time limits." },
  ],
  industrial: [
    { q: "In a 3-phase system, what is the phase difference between each phase?", options: ["60°", "90°", "120°", "180°"], ans: 2, exp: "In a balanced 3-phase system, each phase is displaced by 120° from the others." },
    { q: "A Star (Y) connection has its neutral point at:", options: ["Line terminal", "Common junction of all phases", "Earth terminal", "Phase terminal"], ans: 1, exp: "In a Star connection, one end of each phase winding is connected to a common neutral point." },
    { q: "The line voltage in a Star connection is:", options: ["Equal to phase voltage", "Half of phase voltage", "√3 times phase voltage", "2 times phase voltage"], ans: 2, exp: "VLine = √3 × VPhase in a Star (Y) connected system. For 415V supply, each phase has ~240V." },
    { q: "DOL starter is used for:", options: ["High-voltage motors", "Small motors up to 5HP", "DC motors only", "Synchronous motors"], ans: 1, exp: "Direct On-Line (DOL) starters are used for small motors (typically up to 5 HP / 3.7 kW) where starting current isn't a concern." },
    { q: "IP65 rating means the enclosure is protected against:", options: ["High temperature", "Dust & water jets", "Explosion", "UV radiation"], ans: 1, exp: "IP65 = IP(6)(5): 6 = dust-tight, 5 = protection against water jets from any direction." },
  ],
};

/* ─────────────────────────────────────────────
   ARTICLE CONTENT
───────────────────────────────────────────── */
const ARTICLE_CONTENT = {
  b1: {
    title: "Understanding AC/DC Current",
    body: `**Direct Current (DC)** flows in one direction continuously. Used in batteries, electronic devices, and solar panels. Voltage remains constant.

**Alternating Current (AC)** reverses direction periodically. In India, the standard frequency is 50 Hz, meaning current changes direction 50 times per second. AC is used for domestic and industrial supply.

**Why AC for distribution?**
AC can be easily stepped up/down using transformers, making long-distance transmission efficient. DC experiences higher losses over long distances.

**Key Formulas:**
• Peak Voltage = RMS Voltage × √2  
• For 230V supply: Peak = 230 × 1.414 = **325V**
• RMS = Peak / √2

**Safety Note:** Never assume a circuit is dead. Always use a voltage tester before working.`,
  },
  t1: {
    title: "Megger Insulation Resistance Test",
    body: `**Purpose:** To verify the integrity of cable/wiring insulation before commissioning or after fault investigation.

**Equipment:** Insulation Resistance (IR) Tester (commonly called a "Megger")

**Test Voltages (as per IS 732):**
• Extra-low voltage circuits: 250V DC  
• Up to 500V circuits: 500V DC  
• Above 500V circuits: 1000V DC  

**Procedure:**
1. Isolate the circuit completely — switch off MCBs, disconnect loads
2. Short all phase conductors together
3. Connect one probe to the shorted conductors, other to Earth
4. Apply test voltage for 1 minute
5. Record the resistance value in MΩ

**Acceptance Criteria:**
• Minimum: **1 MΩ** (IS 732 for domestic)
• Good: > **100 MΩ**
• Excellent: > **1000 MΩ**

**Polarization Index (PI):** Ratio of 10-min to 1-min reading. PI > 2 indicates good insulation.`,
  },
};

/* ─────────────────────────────────────────────
   GLOBAL STYLES
───────────────────────────────────────────── */
const G = {
  bg: "#0A0E1A",
  surface: "#111827",
  card: "#1A2235",
  border: "#1E2D45",
  accent: "#F59E0B",
  accentDim: "rgba(245,158,11,0.12)",
  blue: "#3B82F6",
  green: "#10B981",
  red: "#EF4444",
  textPrimary: "#F1F5F9",
  textSecondary: "#94A3B8",
  textMuted: "#475569",
};

/* ─────────────────────────────────────────────
   REUSABLE COMPONENTS
───────────────────────────────────────────── */
const CircuitBg = () => (
  <svg style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", opacity: 0.03, pointerEvents: "none", zIndex: 0 }} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <pattern id="circuit" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
        <path d="M0 40 H30 M50 40 H80 M40 0 V30 M40 50 V80" stroke="#F59E0B" strokeWidth="1" fill="none" />
        <circle cx="40" cy="40" r="4" fill="none" stroke="#F59E0B" strokeWidth="1" />
        <rect x="28" y="36" width="8" height="8" fill="none" stroke="#F59E0B" strokeWidth="1" />
        <rect x="44" y="36" width="8" height="8" fill="none" stroke="#F59E0B" strokeWidth="1" />
        <circle cx="10" cy="40" r="2" fill="#F59E0B" opacity="0.5" />
        <circle cx="70" cy="40" r="2" fill="#F59E0B" opacity="0.5" />
      </pattern>
    </defs>
    <rect width="100%" height="100%" fill="url(#circuit)" />
  </svg>
);

const GlowDot = ({ x, y, color = G.accent }) => (
  <div style={{ position: "absolute", top: y, left: x, width: 6, height: 6, borderRadius: "50%", background: color, boxShadow: `0 0 12px ${color}`, zIndex: 1 }} />
);

const Badge = ({ children, color = G.accent }) => (
  <span style={{ background: `${color}20`, color, border: `1px solid ${color}40`, borderRadius: 4, padding: "2px 8px", fontSize: 10, fontFamily: "monospace", fontWeight: 700, letterSpacing: 1 }}>
    {children}
  </span>
);

const Pill = ({ children, active, onClick, color = G.accent }) => (
  <button onClick={onClick} style={{ background: active ? color : "transparent", color: active ? "#000" : G.textSecondary, border: `1px solid ${active ? color : G.border}`, borderRadius: 20, padding: "6px 16px", fontSize: 12, fontWeight: 700, cursor: "pointer", transition: "all 0.2s", fontFamily: "monospace", letterSpacing: 0.5 }}>
    {children}
  </button>
);

const ProgressBar = ({ value, color = G.accent, height = 6 }) => (
  <div style={{ background: G.border, borderRadius: height, height, overflow: "hidden" }}>
    <div style={{ width: `${value}%`, height: "100%", background: `linear-gradient(90deg, ${color}, ${color}cc)`, borderRadius: height, transition: "width 0.8s cubic-bezier(.4,2,.6,1)", boxShadow: `0 0 8px ${color}80` }} />
  </div>
);

const Card = ({ children, style = {}, onClick }) => (
  <div onClick={onClick} style={{ background: G.card, border: `1px solid ${G.border}`, borderRadius: 12, padding: 16, position: "relative", overflow: "hidden", cursor: onClick ? "pointer" : "default", transition: "border-color 0.2s, transform 0.15s", ...style }}
    onMouseEnter={e => { if (onClick) { e.currentTarget.style.borderColor = G.accent; e.currentTarget.style.transform = "translateY(-2px)"; } }}
    onMouseLeave={e => { e.currentTarget.style.borderColor = G.border; e.currentTarget.style.transform = "translateY(0)"; }}
  >
    {children}
  </div>
);

const Input = ({ label, ...props }) => (
  <div style={{ marginBottom: 16 }}>
    {label && <label style={{ color: G.textSecondary, fontSize: 11, fontFamily: "monospace", letterSpacing: 1, display: "block", marginBottom: 6, textTransform: "uppercase" }}>{label}</label>}
    <input {...props} style={{ width: "100%", background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "12px 14px", color: G.textPrimary, fontSize: 15, fontFamily: "'Courier New', monospace", outline: "none", boxSizing: "border-box", transition: "border-color 0.2s", ...props.style }}
      onFocus={e => e.target.style.borderColor = G.accent}
      onBlur={e => e.target.style.borderColor = G.border}
    />
  </div>
);

const Btn = ({ children, onClick, variant = "primary", disabled, style = {} }) => {
  const styles = {
    primary: { background: `linear-gradient(135deg, ${G.accent}, #D97706)`, color: "#000", border: "none" },
    secondary: { background: "transparent", color: G.accent, border: `1px solid ${G.accent}` },
    danger: { background: `linear-gradient(135deg, ${G.red}, #B91C1C)`, color: "#fff", border: "none" },
    ghost: { background: G.surface, color: G.textPrimary, border: `1px solid ${G.border}` },
  };
  return (
    <button onClick={disabled ? undefined : onClick} disabled={disabled} style={{ ...styles[variant], borderRadius: 8, padding: "12px 24px", fontSize: 14, fontWeight: 700, cursor: disabled ? "not-allowed" : "pointer", fontFamily: "monospace", letterSpacing: 0.5, width: "100%", opacity: disabled ? 0.5 : 1, transition: "opacity 0.2s, transform 0.1s", ...style }}
      onMouseDown={e => { if (!disabled) e.currentTarget.style.transform = "scale(0.98)"; }}
      onMouseUp={e => { e.currentTarget.style.transform = "scale(1)"; }}
    >
      {children}
    </button>
  );
};

/* ─────────────────────────────────────────────
   MINI CHART (SVG)
───────────────────────────────────────────── */
const SparkLine = ({ data, color = G.accent, width = 120, height = 40 }) => {
  if (!data?.length) return null;
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 8) - 4;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg width={width} height={height} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`g${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <polygon points={`0,${height} ${pts} ${width},${height}`} fill={`url(#g${color.replace("#", "")})`} />
      {data.map((v, i) => {
        const x = (i / (data.length - 1)) * width;
        const y = height - ((v - min) / range) * (height - 8) - 4;
        return <circle key={i} cx={x} cy={y} r="3" fill={color} />;
      })}
    </svg>
  );
};

const DonutChart = ({ value, size = 80, color = G.accent }) => {
  const r = 30, circ = 2 * Math.PI * r;
  const dash = (value / 100) * circ;
  return (
    <svg width={size} height={size} viewBox="0 0 80 80">
      <circle cx="40" cy="40" r={r} fill="none" stroke={G.border} strokeWidth="8" />
      <circle cx="40" cy="40" r={r} fill="none" stroke={color} strokeWidth="8"
        strokeDasharray={`${dash} ${circ}`} strokeDashoffset={circ / 4}
        strokeLinecap="round" style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
      <text x="40" y="45" textAnchor="middle" fill={color} fontSize="14" fontWeight="bold" fontFamily="monospace">{value}%</text>
    </svg>
  );
};

/* ─────────────────────────────────────────────
   SCREEN: OTP LOGIN
───────────────────────────────────────────── */
const OTPScreen = ({ onLogin }) => {
  const [step, setStep] = useState("phone"); // phone | otp | loading
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [timer, setTimer] = useState(0);
  const [error, setError] = useState("");
  const [confirmResult, setConfirmResult] = useState(null);
  const otpRefs = useRef([]);

  useEffect(() => {
    if (timer > 0) { const t = setTimeout(() => setTimer(t => t - 1), 1000); return () => clearTimeout(t); }
  }, [timer]);

  const sendOTP = async () => {
    if (phone.length < 10) { setError("Enter a valid 10-digit number"); return; }
    setError(""); setStep("loading");
    try {
      if (!window.recaptchaVerifier) {
        window.recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", { size: "invisible" });
      }
      const result = await signInWithPhoneNumber(auth, `+91${phone}`, window.recaptchaVerifier);
      setConfirmResult(result);
      setStep("otp"); setTimer(30);
    } catch (e) {
      setError("OTP send failed. Using demo mode.");
      setConfirmResult({ confirm: async (code) => { if (code === "123456") return { user: { uid: "demo_" + phone, phoneNumber: "+91" + phone } }; throw new Error("Wrong OTP"); } });
      setStep("otp"); setTimer(30);
    }
  };

  const verifyOTP = async () => {
    const code = otp.join("");
    if (code.length < 6) { setError("Enter complete 6-digit OTP"); return; }
    setError(""); setStep("loading");
    try {
      const result = await confirmResult.confirm(code);
      onLogin(result.user);
    } catch (e) {
      setError("Invalid OTP. For demo, use: 123456");
      setStep("otp");
    }
  };

  const handleOtpChange = (i, val) => {
    if (!/^\d*$/.test(val)) return;
    const next = [...otp]; next[i] = val.slice(-1);
    setOtp(next);
    if (val && i < 5) otpRefs.current[i + 1]?.focus();
    if (!val && i > 0) otpRefs.current[i - 1]?.focus();
  };

  return (
    <div style={{ minHeight: "100vh", background: G.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 20, position: "relative" }}>
      <CircuitBg />
      <div id="recaptcha-container" />
      <div style={{ width: "100%", maxWidth: 380, position: "relative", zIndex: 2 }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ width: 72, height: 72, background: G.accentDim, border: `2px solid ${G.accent}`, borderRadius: 16, display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 16, boxShadow: `0 0 30px ${G.accent}40` }}>
            <span style={{ fontSize: 36 }}>⚡</span>
          </div>
          <div style={{ color: G.accent, fontFamily: "monospace", fontSize: 22, fontWeight: 900, letterSpacing: 3, textTransform: "uppercase" }}>ELECTRA</div>
          <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace", letterSpacing: 2, marginTop: 4 }}>LEARNING · PLATFORM</div>
        </div>

        <Card>
          {step === "loading" && (
            <div style={{ textAlign: "center", padding: "40px 0" }}>
              <div style={{ width: 48, height: 48, border: `3px solid ${G.border}`, borderTopColor: G.accent, borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px" }} />
              <div style={{ color: G.textSecondary, fontFamily: "monospace" }}>Verifying...</div>
            </div>
          )}

          {step === "phone" && (
            <>
              <div style={{ color: G.textPrimary, fontSize: 18, fontWeight: 700, fontFamily: "monospace", marginBottom: 4 }}>Sign In / Register</div>
              <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace", marginBottom: 24 }}>Enter your mobile number to continue</div>
              <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                <div style={{ background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "12px 14px", color: G.textSecondary, fontFamily: "monospace", fontSize: 15, whiteSpace: "nowrap" }}>🇮🇳 +91</div>
                <input value={phone} onChange={e => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))} placeholder="98765 43210" maxLength={10} type="tel"
                  style={{ flex: 1, background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "12px 14px", color: G.textPrimary, fontSize: 15, fontFamily: "monospace", outline: "none" }}
                  onFocus={e => e.target.style.borderColor = G.accent} onBlur={e => e.target.style.borderColor = G.border}
                />
              </div>
              {error && <div style={{ color: G.red, fontSize: 12, fontFamily: "monospace", marginBottom: 12 }}>⚠ {error}</div>}
              <Btn onClick={sendOTP} disabled={phone.length < 10}>Send OTP →</Btn>
              <div style={{ textAlign: "center", marginTop: 16, color: G.textMuted, fontSize: 11, fontFamily: "monospace" }}>
                By continuing, you agree to our Terms of Service
              </div>
            </>
          )}

          {step === "otp" && (
            <>
              <div style={{ color: G.textPrimary, fontSize: 18, fontWeight: 700, fontFamily: "monospace", marginBottom: 4 }}>Enter OTP</div>
              <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace", marginBottom: 24 }}>Sent to +91 {phone} · <span style={{ color: G.accent, cursor: "pointer" }} onClick={() => setStep("phone")}>Change</span></div>
              <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 20 }}>
                {otp.map((v, i) => (
                  <input key={i} ref={el => otpRefs.current[i] = el} value={v} onChange={e => handleOtpChange(i, e.target.value)} maxLength={1} type="tel"
                    style={{ width: 44, height: 52, textAlign: "center", background: v ? G.accentDim : G.surface, border: `2px solid ${v ? G.accent : G.border}`, borderRadius: 8, color: G.accent, fontSize: 22, fontFamily: "monospace", fontWeight: 700, outline: "none" }}
                  />
                ))}
              </div>
              {error && <div style={{ color: G.red, fontSize: 12, fontFamily: "monospace", marginBottom: 12 }}>⚠ {error}</div>}
              <Btn onClick={verifyOTP} disabled={otp.join("").length < 6}>Verify & Continue ✓</Btn>
              <div style={{ textAlign: "center", marginTop: 12 }}>
                {timer > 0 ? (
                  <span style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 12 }}>Resend OTP in {timer}s</span>
                ) : (
                  <span style={{ color: G.accent, fontFamily: "monospace", fontSize: 12, cursor: "pointer" }} onClick={sendOTP}>Resend OTP</span>
                )}
              </div>
              <div style={{ marginTop: 12, padding: "8px 12px", background: `${G.blue}15`, border: `1px solid ${G.blue}30`, borderRadius: 8, textAlign: "center" }}>
                <span style={{ color: G.blue, fontFamily: "monospace", fontSize: 11 }}>DEMO MODE: Use OTP → 123456</span>
              </div>
            </>
          )}
        </Card>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
};

/* ─────────────────────────────────────────────
   SCREEN: PROFILE SETUP
───────────────────────────────────────────── */
const ProfileSetup = ({ user, onComplete }) => {
  const [form, setForm] = useState({ name: "", age: "", qualification: "10th Pass", experience: "Fresher", specialization: "General" });
  const [loading, setLoading] = useState(false);
  const qualOpts = ["8th Pass", "10th Pass", "12th Pass", "ITI", "Diploma", "B.Tech/BE", "Other"];
  const expOpts = ["Fresher", "0-1 Year", "1-3 Years", "3-5 Years", "5+ Years"];
  const specOpts = ["General", "Residential", "Industrial", "Maintenance", "Solar/Renewable"];

  const save = async () => {
    if (!form.name || !form.age) return;
    setLoading(true);
    try {
      await setDoc(doc(db, "users", user.uid), {
        ...form, phone: user.phoneNumber, uid: user.uid,
        createdAt: serverTimestamp(), totalXP: 0, level: 1,
        studyStreak: 0, completedTopics: [], testResults: [],
      });
    } catch (e) { console.warn("Firestore:", e.message); }
    onComplete({ ...user, profile: form });
  };

  const SelectRow = ({ label, field, opts }) => (
    <div style={{ marginBottom: 16 }}>
      <label style={{ color: G.textSecondary, fontSize: 11, fontFamily: "monospace", letterSpacing: 1, display: "block", marginBottom: 8, textTransform: "uppercase" }}>{label}</label>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {opts.map(o => (
          <button key={o} onClick={() => setForm(f => ({ ...f, [field]: o }))}
            style={{ padding: "6px 12px", borderRadius: 6, fontSize: 12, fontFamily: "monospace", cursor: "pointer", transition: "all 0.15s", background: form[field] === o ? G.accent : G.surface, color: form[field] === o ? "#000" : G.textSecondary, border: `1px solid ${form[field] === o ? G.accent : G.border}`, fontWeight: form[field] === o ? 700 : 400 }}>
            {o}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: G.bg, position: "relative", padding: "0 0 40px" }}>
      <CircuitBg />
      <div style={{ maxWidth: 480, margin: "0 auto", padding: "40px 20px", position: "relative", zIndex: 2 }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ color: G.accent, fontFamily: "monospace", fontSize: 11, letterSpacing: 2, marginBottom: 8 }}>STEP 1 OF 1</div>
          <div style={{ color: G.textPrimary, fontSize: 24, fontWeight: 900, fontFamily: "monospace", marginBottom: 6 }}>Build Your Profile</div>
          <div style={{ color: G.textMuted, fontSize: 13, fontFamily: "monospace" }}>Personalize your learning experience</div>
        </div>

        <Card style={{ marginBottom: 16 }}>
          <Input label="Full Name" placeholder="e.g., Ramesh Kumar" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          <Input label="Age" placeholder="e.g., 24" type="number" value={form.age} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} />
          <SelectRow label="Current Qualification" field="qualification" opts={qualOpts} />
          <SelectRow label="Work Experience" field="experience" opts={expOpts} />
          <SelectRow label="Specialization" field="specialization" opts={specOpts} />
        </Card>

        <Btn onClick={save} disabled={!form.name || !form.age || loading}>
          {loading ? "Saving..." : "Start Learning ⚡"}
        </Btn>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   BOTTOM NAV
───────────────────────────────────────────── */
const NAV_ITEMS = [
  { id: "home", icon: "⊞", label: "Home" },
  { id: "study", icon: "📚", label: "Study Hub" },
  { id: "tests", icon: "✎", label: "Tests" },
  { id: "progress", icon: "◎", label: "Progress" },
  { id: "profile", icon: "◉", label: "Profile" },
];
const BottomNav = ({ active, onChange }) => (
  <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: G.surface, borderTop: `1px solid ${G.border}`, display: "flex", zIndex: 100, maxWidth: 480, margin: "0 auto" }}>
    {NAV_ITEMS.map(n => (
      <button key={n.id} onClick={() => onChange(n.id)} style={{ flex: 1, padding: "10px 0 12px", background: "transparent", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
        <span style={{ fontSize: 18, filter: active === n.id ? `drop-shadow(0 0 6px ${G.accent})` : "none", transition: "filter 0.2s" }}>{n.icon}</span>
        <span style={{ fontSize: 9, fontFamily: "monospace", fontWeight: 700, letterSpacing: 0.5, color: active === n.id ? G.accent : G.textMuted, transition: "color 0.2s" }}>{n.label}</span>
        {active === n.id && <div style={{ width: 16, height: 2, background: G.accent, borderRadius: 2, boxShadow: `0 0 6px ${G.accent}` }} />}
      </button>
    ))}
  </div>
);

/* ─────────────────────────────────────────────
   SCREEN: DASHBOARD
───────────────────────────────────────────── */
const Dashboard = ({ userData, onNav }) => {
  const profile = userData?.profile || {};
  const name = profile.name || "Learner";
  const scoreHistory = [45, 60, 55, 70, 65, 80, 75, 88];
  const recentTests = [
    { title: "Basic Wiring Quiz", score: 88, total: 100, date: "Today", status: "pass" },
    { title: "Testing Procedures", score: 72, total: 100, date: "Yesterday", status: "pass" },
    { title: "Industrial Wiring", score: 48, total: 100, date: "2 days ago", status: "fail" },
  ];
  const statsCards = [
    { label: "Tests Taken", value: "12", icon: "✎", color: G.accent },
    { label: "Avg Score", value: "74%", icon: "◎", color: G.green },
    { label: "Study Time", value: "8h", icon: "⏱", color: G.blue },
    { label: "Streak", value: "5d", icon: "🔥", color: "#F97316" },
  ];

  return (
    <div style={{ paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: `linear-gradient(135deg, #0D1B2A, #0A0E1A)`, padding: "32px 20px 24px", borderBottom: `1px solid ${G.border}`, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -20, right: -20, width: 120, height: 120, background: `${G.accent}08`, borderRadius: "50%", border: `1px solid ${G.accent}15` }} />
        <div style={{ position: "absolute", top: 20, right: 20, width: 60, height: 60, background: `${G.accent}06`, borderRadius: "50%", border: `1px solid ${G.accent}10` }} />
        <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 11, letterSpacing: 2, marginBottom: 6 }}>GOOD MORNING</div>
        <div style={{ color: G.textPrimary, fontSize: 22, fontWeight: 900, fontFamily: "monospace", marginBottom: 4 }}>⚡ {name}</div>
        <div style={{ color: G.textSecondary, fontSize: 12, fontFamily: "monospace" }}>{profile.specialization || "General"} · {profile.experience || "Learner"}</div>

        {/* XP Bar */}
        <div style={{ marginTop: 16, background: G.surface, borderRadius: 12, padding: "12px 14px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ color: G.accent, fontFamily: "monospace", fontSize: 11, fontWeight: 700 }}>LEVEL 3 · APPRENTICE</span>
            <span style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 11 }}>640 / 1000 XP</span>
          </div>
          <ProgressBar value={64} color={G.accent} height={8} />
        </div>
      </div>

      <div style={{ padding: "20px 16px" }}>
        {/* Stats Grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24 }}>
          {statsCards.map((s, i) => (
            <Card key={i} style={{ padding: "14px 16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10, letterSpacing: 1, marginBottom: 4 }}>{s.label.toUpperCase()}</div>
                  <div style={{ color: s.color, fontSize: 26, fontFamily: "monospace", fontWeight: 900 }}>{s.value}</div>
                </div>
                <span style={{ fontSize: 20, opacity: 0.7 }}>{s.icon}</span>
              </div>
            </Card>
          ))}
        </div>

        {/* Score trend */}
        <Card style={{ marginBottom: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div>
              <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14 }}>Score Trend</div>
              <div style={{ color: G.textMuted, fontSize: 11, fontFamily: "monospace" }}>Last 8 tests</div>
            </div>
            <Badge color={G.green}>+18% ↑</Badge>
          </div>
          <SparkLine data={scoreHistory} color={G.accent} width={300} height={60} />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {scoreHistory.map((s, i) => (
              <div key={i} style={{ color: G.textMuted, fontSize: 9, fontFamily: "monospace", textAlign: "center" }}>{s}</div>
            ))}
          </div>
        </Card>

        {/* Quick Access */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Quick Access</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {[
              { icon: "📖", label: "Study Hub", sub: "48 articles", nav: "study", color: G.accent },
              { icon: "📝", label: "Mock Tests", sub: "Take a test now", nav: "tests", color: G.blue },
              { icon: "📊", label: "Progress", sub: "View charts", nav: "progress", color: G.green },
              { icon: "🏆", label: "Leaderboard", sub: "Rank #23", nav: "progress", color: "#F97316" },
            ].map((q, i) => (
              <Card key={i} onClick={() => onNav(q.nav)} style={{ padding: "14px" }}>
                <div style={{ fontSize: 24, marginBottom: 8 }}>{q.icon}</div>
                <div style={{ color: q.color, fontFamily: "monospace", fontWeight: 700, fontSize: 13 }}>{q.label}</div>
                <div style={{ color: G.textMuted, fontSize: 11, fontFamily: "monospace" }}>{q.sub}</div>
              </Card>
            ))}
          </div>
        </div>

        {/* Recent Tests */}
        <div>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Recent Tests</div>
          {recentTests.map((t, i) => (
            <Card key={i} style={{ marginBottom: 10, padding: "14px 16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 13, fontWeight: 700, marginBottom: 2 }}>{t.title}</div>
                  <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 11 }}>{t.date}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ color: t.status === "pass" ? G.green : G.red, fontFamily: "monospace", fontSize: 18, fontWeight: 900 }}>{t.score}%</div>
                  <Badge color={t.status === "pass" ? G.green : G.red}>{t.status === "pass" ? "PASS" : "FAIL"}</Badge>
                </div>
              </div>
              <div style={{ marginTop: 10 }}>
                <ProgressBar value={t.score} color={t.status === "pass" ? G.green : G.red} height={4} />
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   SCREEN: STUDY HUB
───────────────────────────────────────────── */
const StudyHub = () => {
  const [activeModule, setActiveModule] = useState(null);
  const [activeArticle, setActiveArticle] = useState(null);
  const [filter, setFilter] = useState("All");

  if (activeArticle) {
    const content = ARTICLE_CONTENT[activeArticle.id];
    const renderContent = (text) => text.split("\n\n").map((para, i) => (
      <p key={i} style={{ color: para.startsWith("**") ? G.textPrimary : G.textSecondary, fontFamily: "monospace", fontSize: 13, lineHeight: 1.8, marginBottom: 12 }}>
        {para.replace(/\*\*(.*?)\*\*/g, (_, t) => `⬛${t}⬛`).split("⬛").map((s, j) => j % 2 === 1 ? <strong key={j} style={{ color: G.accent }}>{s}</strong> : s)}
      </p>
    ));
    return (
      <div style={{ paddingBottom: 80 }}>
        <div style={{ background: G.surface, padding: "16px 20px", borderBottom: `1px solid ${G.border}`, display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={() => setActiveArticle(null)} style={{ background: "transparent", border: "none", color: G.accent, fontSize: 18, cursor: "pointer" }}>←</button>
          <div>
            <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14 }}>{content?.title || activeArticle.title}</div>
            <Badge>{activeArticle.tag}</Badge>
          </div>
        </div>
        <div style={{ padding: 20 }}>
          <Card>
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
              <Badge color={G.blue}>⏱ {activeArticle.duration}</Badge>
              <Badge color={G.green}>📖 Article</Badge>
            </div>
            {content ? renderContent(content.body) : (
              <div style={{ color: G.textSecondary, fontFamily: "monospace", fontSize: 13, lineHeight: 1.8 }}>
                <p>This comprehensive module covers all essential aspects of <strong style={{ color: G.accent }}>{activeArticle.title}</strong>.</p>
                <p>Content covers theoretical foundations, practical application techniques, relevant IS codes and standards, common troubleshooting approaches, and safety best practices recognized in the Indian electrical industry.</p>
                <p style={{ padding: "12px 16px", background: `${G.blue}15`, border: `1px solid ${G.blue}30`, borderRadius: 8 }}>
                  📌 <span style={{ color: G.blue }}>Full PDF content available in the mobile app. This is a preview of the study material.</span>
                </p>
              </div>
            )}
          </Card>
        </div>
      </div>
    );
  }

  if (activeModule) {
    return (
      <div style={{ paddingBottom: 80 }}>
        <div style={{ background: `linear-gradient(135deg, ${activeModule.color}20, ${G.surface})`, padding: "24px 20px", borderBottom: `1px solid ${G.border}` }}>
          <button onClick={() => setActiveModule(null)} style={{ background: "transparent", border: "none", color: G.textSecondary, fontSize: 13, fontFamily: "monospace", cursor: "pointer", marginBottom: 12, padding: 0 }}>← All Modules</button>
          <div style={{ fontSize: 36, marginBottom: 8 }}>{activeModule.icon}</div>
          <div style={{ color: activeModule.color, fontSize: 20, fontWeight: 900, fontFamily: "monospace" }}>{activeModule.title}</div>
          <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace", marginTop: 4 }}>{activeModule.desc}</div>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <Badge color={activeModule.color}>{activeModule.topics} TOPICS</Badge>
            <Badge color={G.green}>FREE ACCESS</Badge>
          </div>
        </div>
        <div style={{ padding: "16px 16px 0" }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 13, marginBottom: 12 }}>ARTICLES IN THIS MODULE</div>
          {activeModule.articles.map((a, i) => (
            <Card key={a.id} onClick={() => setActiveArticle(a)} style={{ marginBottom: 10, padding: "14px 16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 13, fontWeight: 700, marginBottom: 6 }}>{a.title}</div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <Badge color={activeModule.color}>{a.tag}</Badge>
                    <span style={{ color: G.textMuted, fontSize: 11, fontFamily: "monospace" }}>⏱ {a.duration}</span>
                  </div>
                </div>
                <div style={{ color: G.accent, fontSize: 18 }}>→</div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: G.surface, padding: "20px 20px 16px", borderBottom: `1px solid ${G.border}` }}>
        <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 18, fontWeight: 900, marginBottom: 4 }}>Study Hub 📚</div>
        <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace" }}>48 articles · 4 modules · PDFs included</div>
        <div style={{ display: "flex", gap: 8, marginTop: 12, overflowX: "auto", paddingBottom: 4 }}>
          {["All", "Basics", "Industrial", "Testing", "Safety"].map(f => (
            <Pill key={f} active={filter === f} onClick={() => setFilter(f)}>{f}</Pill>
          ))}
        </div>
      </div>
      <div style={{ padding: "16px" }}>
        {STUDY_MODULES.map((m, i) => (
          <Card key={m.id} onClick={() => setActiveModule(m)} style={{ marginBottom: 14, padding: "18px" }}>
            <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
              <div style={{ width: 52, height: 52, background: `${m.color}15`, border: `1px solid ${m.color}40`, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>{m.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 14, fontWeight: 700, marginBottom: 4 }}>{m.title}</div>
                <div style={{ color: G.textMuted, fontSize: 11, fontFamily: "monospace", lineHeight: 1.5, marginBottom: 10 }}>{m.desc}</div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <Badge color={m.color}>{m.topics} TOPICS</Badge>
                  <span style={{ color: m.color, fontSize: 13, fontFamily: "monospace" }}>Explore →</span>
                </div>
              </div>
            </div>
            <div style={{ marginTop: 12 }}>
              <ProgressBar value={Math.floor(Math.random() * 60 + 20)} color={m.color} height={4} />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   SCREEN: QUIZ ENGINE
───────────────────────────────────────────── */
const TestScreen = ({ userData }) => {
  const [phase, setPhase] = useState("select"); // select | active | result
  const [selectedModule, setSelectedModule] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [result, setResult] = useState(null);
  const timerRef = useRef();

  const TOTAL_TIME = 300; // 5 min

  const startQuiz = (moduleId) => {
    const qs = QUIZ_BANK[moduleId] || QUIZ_BANK.basic;
    setSelectedModule(moduleId);
    setQuestions(qs);
    setAnswers({});
    setCurrent(0);
    setTimeLeft(TOTAL_TIME);
    setPhase("active");
  };

  useEffect(() => {
    if (phase === "active") {
      timerRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) { clearInterval(timerRef.current); submitQuiz(); return 0; }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [phase]);

  const submitQuiz = () => {
    clearInterval(timerRef.current);
    const score = questions.reduce((acc, q, i) => acc + (answers[i] === q.ans ? 1 : 0), 0);
    const pct = Math.round((score / questions.length) * 100);
    const res = { score, total: questions.length, pct, pass: pct >= 60, answers: { ...answers } };
    setResult(res);
    setPhase("result");
    // Save to Firestore
    try {
      addDoc(collection(db, "users", userData?.uid || "demo", "testResults"), {
        moduleId: selectedModule, score, total: questions.length, pct,
        pass: pct >= 60, timestamp: serverTimestamp()
      });
    } catch (e) { }
  };

  const selectAnswer = (qi, ai) => setAnswers(a => ({ ...a, [qi]: ai }));

  const mins = String(Math.floor(timeLeft / 60)).padStart(2, "0");
  const secs = String(timeLeft % 60).padStart(2, "0");
  const timeColor = timeLeft < 60 ? G.red : timeLeft < 120 ? G.accent : G.green;

  if (phase === "select") {
    return (
      <div style={{ paddingBottom: 80 }}>
        <div style={{ background: G.surface, padding: "20px 20px 16px", borderBottom: `1px solid ${G.border}` }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 18, fontWeight: 900, marginBottom: 4 }}>Mock Tests ✎</div>
          <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace" }}>5 questions · 5 minutes · MCQ format</div>
        </div>
        <div style={{ padding: 16 }}>
          <Card style={{ marginBottom: 16, background: `${G.accent}10`, border: `1px solid ${G.accent}30` }}>
            <div style={{ color: G.accent, fontFamily: "monospace", fontSize: 12, fontWeight: 700, marginBottom: 4 }}>📋 EXAM FORMAT</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 8 }}>
              {[["Questions", "5 MCQ"], ["Time Limit", "5 Minutes"], ["Pass Mark", "60%"], ["Attempts", "Unlimited"]].map(([k, v]) => (
                <div key={k} style={{ background: G.card, borderRadius: 8, padding: "8px 10px" }}>
                  <div style={{ color: G.textMuted, fontSize: 10, fontFamily: "monospace" }}>{k}</div>
                  <div style={{ color: G.textPrimary, fontSize: 13, fontFamily: "monospace", fontWeight: 700 }}>{v}</div>
                </div>
              ))}
            </div>
          </Card>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 13, marginBottom: 12 }}>SELECT MODULE</div>
          {[
            { id: "basic", icon: "⚡", label: "Basic Wiring", color: G.accent, questions: 5 },
            { id: "testing", icon: "🔬", label: "Testing Procedures", color: G.green, questions: 5 },
            { id: "industrial", icon: "🏭", label: "Industrial Systems", color: G.blue, questions: 5 },
          ].map(m => (
            <Card key={m.id} onClick={() => startQuiz(m.id)} style={{ marginBottom: 10, padding: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ fontSize: 28 }}>{m.icon}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ color: m.color, fontFamily: "monospace", fontWeight: 700, fontSize: 14 }}>{m.label}</div>
                  <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 11 }}>{m.questions} questions · 5 min</div>
                </div>
                <Btn variant="secondary" style={{ width: "auto", padding: "8px 16px", fontSize: 12 }} onClick={() => startQuiz(m.id)}>Start</Btn>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (phase === "result") {
    const q = questions;
    return (
      <div style={{ paddingBottom: 80 }}>
        <div style={{ background: result.pass ? `${G.green}15` : `${G.red}15`, padding: "32px 20px", textAlign: "center", borderBottom: `1px solid ${G.border}` }}>
          <div style={{ fontSize: 52, marginBottom: 8 }}>{result.pass ? "🏆" : "📚"}</div>
          <DonutChart value={result.pct} size={100} color={result.pass ? G.green : G.red} />
          <div style={{ color: result.pass ? G.green : G.red, fontFamily: "monospace", fontSize: 20, fontWeight: 900, marginTop: 12 }}>
            {result.pass ? "PASSED!" : "NEEDS PRACTICE"}
          </div>
          <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 13, marginTop: 4 }}>
            {result.score}/{result.total} correct · {result.pct}%
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 16, justifyContent: "center" }}>
            <Btn variant="secondary" style={{ width: "auto", padding: "10px 20px" }} onClick={() => { setPhase("select"); setResult(null); }}>New Test</Btn>
            <Btn style={{ width: "auto", padding: "10px 20px" }} onClick={() => startQuiz(selectedModule)}>Retry</Btn>
          </div>
        </div>
        <div style={{ padding: "16px" }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 13, marginBottom: 12 }}>ANSWER REVIEW</div>
          {q.map((question, i) => {
            const ua = result.answers[i];
            const correct = ua === question.ans;
            return (
              <Card key={i} style={{ marginBottom: 12, borderColor: correct ? `${G.green}40` : `${G.red}40` }}>
                <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
                  <span style={{ fontSize: 16 }}>{correct ? "✅" : "❌"}</span>
                  <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 13, fontWeight: 700, flex: 1 }}>Q{i + 1}. {question.q}</div>
                </div>
                {question.options.map((o, j) => (
                  <div key={j} style={{ padding: "6px 10px", borderRadius: 6, marginBottom: 4, background: j === question.ans ? `${G.green}20` : j === ua && !correct ? `${G.red}20` : "transparent", border: `1px solid ${j === question.ans ? G.green + "40" : j === ua && !correct ? G.red + "40" : G.border}` }}>
                    <span style={{ color: j === question.ans ? G.green : j === ua && !correct ? G.red : G.textMuted, fontFamily: "monospace", fontSize: 12 }}>
                      {j === question.ans ? "✓ " : j === ua && !correct ? "✗ " : "  "}{o}
                    </span>
                  </div>
                ))}
                <div style={{ marginTop: 8, padding: "8px 10px", background: `${G.blue}15`, borderRadius: 6, border: `1px solid ${G.blue}30` }}>
                  <span style={{ color: G.blue, fontFamily: "monospace", fontSize: 11 }}>💡 {question.exp}</span>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    );
  }

  // Active quiz
  const q = questions[current];
  const answered = answers[current] !== undefined;
  const progress = ((current + 1) / questions.length) * 100;

  return (
    <div style={{ minHeight: "100vh", background: G.bg, paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: G.surface, padding: "14px 20px", borderBottom: `1px solid ${G.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          {questions.map((_, i) => (
            <div key={i} style={{ width: 8, height: 8, borderRadius: "50%", background: answers[i] !== undefined ? G.accent : i === current ? G.blue : G.border, transition: "background 0.2s" }} />
          ))}
        </div>
        <div style={{ color: timeColor, fontFamily: "monospace", fontSize: 18, fontWeight: 900, letterSpacing: 2, textShadow: `0 0 12px ${timeColor}` }}>
          ⏱ {mins}:{secs}
        </div>
      </div>
      <div style={{ height: 3, background: G.border }}>
        <div style={{ width: `${progress}%`, height: "100%", background: `linear-gradient(90deg, ${G.accent}, ${G.blue})`, transition: "width 0.4s" }} />
      </div>

      <div style={{ padding: "20px 16px" }}>
        <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 11, letterSpacing: 1, marginBottom: 8 }}>QUESTION {current + 1} OF {questions.length}</div>
        <Card style={{ marginBottom: 20, padding: "20px" }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 15, fontWeight: 700, lineHeight: 1.6 }}>{q.q}</div>
        </Card>

        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
          {q.options.map((opt, i) => {
            const isSelected = answers[current] === i;
            const optColors = [G.accent, G.blue, G.green, "#F97316"];
            return (
              <button key={i} onClick={() => selectAnswer(current, i)}
                style={{ background: isSelected ? `${optColors[i]}20` : G.card, border: `2px solid ${isSelected ? optColors[i] : G.border}`, borderRadius: 10, padding: "14px 16px", cursor: "pointer", textAlign: "left", transition: "all 0.2s", display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 28, height: 28, borderRadius: "50%", background: isSelected ? optColors[i] : G.surface, border: `2px solid ${isSelected ? optColors[i] : G.border}`, display: "flex", alignItems: "center", justifyContent: "center", color: isSelected ? "#000" : G.textMuted, fontSize: 12, fontFamily: "monospace", fontWeight: 700, flexShrink: 0 }}>
                  {String.fromCharCode(65 + i)}
                </div>
                <span style={{ color: isSelected ? optColors[i] : G.textPrimary, fontFamily: "monospace", fontSize: 13, fontWeight: isSelected ? 700 : 400 }}>{opt}</span>
              </button>
            );
          })}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          {current > 0 && <Btn variant="ghost" style={{ flex: 1 }} onClick={() => setCurrent(c => c - 1)}>← Prev</Btn>}
          {current < questions.length - 1 ? (
            <Btn style={{ flex: 1 }} disabled={!answered} onClick={() => setCurrent(c => c + 1)}>Next →</Btn>
          ) : (
            <Btn style={{ flex: 1 }} onClick={submitQuiz} variant={answered ? "primary" : "ghost"}>Submit ✓</Btn>
          )}
        </div>

        {/* Question palette */}
        <div style={{ marginTop: 20, padding: "14px", background: G.card, borderRadius: 10, border: `1px solid ${G.border}` }}>
          <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10, letterSpacing: 1, marginBottom: 10 }}>QUESTION NAVIGATOR</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {questions.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)} style={{ width: 36, height: 36, borderRadius: 8, border: `2px solid ${i === current ? G.accent : answers[i] !== undefined ? G.green + "80" : G.border}`, background: i === current ? G.accentDim : answers[i] !== undefined ? `${G.green}15` : "transparent", color: i === current ? G.accent : answers[i] !== undefined ? G.green : G.textMuted, fontFamily: "monospace", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   SCREEN: PROGRESS
───────────────────────────────────────────── */
const ProgressScreen = () => {
  const moduleProgress = [
    { label: "Basic Wiring", value: 75, color: G.accent },
    { label: "Industrial", value: 40, color: G.blue },
    { label: "Testing", value: 60, color: G.green },
    { label: "Safety", value: 85, color: G.red },
  ];
  const weekScores = [55, 70, 65, 80, 72, 88, 76];
  const days = ["M", "T", "W", "T", "F", "S", "S"];

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: G.surface, padding: "20px 20px 16px", borderBottom: `1px solid ${G.border}` }}>
        <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 18, fontWeight: 900, marginBottom: 4 }}>Progress ◎</div>
        <div style={{ color: G.textMuted, fontSize: 12, fontFamily: "monospace" }}>Your learning analytics</div>
      </div>
      <div style={{ padding: 16 }}>

        {/* Overall stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 20 }}>
          {[["74%", "Avg Score", G.accent], ["12", "Tests Done", G.blue], ["5🔥", "Day Streak", "#F97316"]].map(([v, l, c]) => (
            <Card key={l} style={{ textAlign: "center", padding: "14px 8px" }}>
              <div style={{ color: c, fontFamily: "monospace", fontSize: 20, fontWeight: 900 }}>{v}</div>
              <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10, marginTop: 2 }}>{l}</div>
            </Card>
          ))}
        </div>

        {/* Weekly bar chart */}
        <Card style={{ marginBottom: 20 }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Weekly Scores</div>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", height: 80 }}>
            {weekScores.map((s, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 9 }}>{s}</div>
                <div style={{ width: "100%", height: (s / 100) * 64, background: `linear-gradient(180deg, ${G.accent}, ${G.accent}80)`, borderRadius: "4px 4px 0 0", boxShadow: `0 0 8px ${G.accent}40`, position: "relative" }}>
                  {i === 5 && <div style={{ position: "absolute", top: -4, left: "50%", transform: "translateX(-50%)", width: 8, height: 8, borderRadius: "50%", background: G.accent, boxShadow: `0 0 8px ${G.accent}` }} />}
                </div>
                <div style={{ color: i === 5 ? G.accent : G.textMuted, fontFamily: "monospace", fontSize: 9, fontWeight: i === 5 ? 700 : 400 }}>{days[i]}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* Module progress */}
        <Card style={{ marginBottom: 20 }}>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Module Completion</div>
          {moduleProgress.map(m => (
            <div key={m.label} style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ color: G.textSecondary, fontFamily: "monospace", fontSize: 12 }}>{m.label}</span>
                <span style={{ color: m.color, fontFamily: "monospace", fontSize: 12, fontWeight: 700 }}>{m.value}%</span>
              </div>
              <ProgressBar value={m.value} color={m.color} height={8} />
            </div>
          ))}
        </Card>

        {/* Score trend */}
        <Card>
          <div style={{ color: G.textPrimary, fontFamily: "monospace", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Score Trend (Last 8 Tests)</div>
          <SparkLine data={[45, 60, 55, 70, 65, 80, 75, 88]} color={G.accent} width={300} height={80} />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            <span style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10 }}>Test 1</span>
            <span style={{ color: G.green, fontFamily: "monospace", fontSize: 10 }}>Improving ↑ +95%</span>
            <span style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10 }}>Latest</span>
          </div>
        </Card>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   SCREEN: PROFILE & SETTINGS
───────────────────────────────────────────── */
const ProfileScreen = ({ userData, onLogout }) => {
  const profile = userData?.profile || {};
  const [notif, setNotif] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  const Toggle = ({ val, onChange }) => (
    <div onClick={() => onChange(!val)} style={{ width: 44, height: 24, background: val ? G.accent : G.border, borderRadius: 12, position: "relative", cursor: "pointer", transition: "background 0.2s", flexShrink: 0 }}>
      <div style={{ position: "absolute", top: 3, left: val ? 23 : 3, width: 18, height: 18, background: val ? "#000" : G.textMuted, borderRadius: "50%", transition: "left 0.2s" }} />
    </div>
  );

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: `linear-gradient(135deg, #0D1B2A, ${G.surface})`, padding: "32px 20px 24px", textAlign: "center", borderBottom: `1px solid ${G.border}` }}>
        <div style={{ width: 80, height: 80, background: G.accentDim, border: `3px solid ${G.accent}`, borderRadius: "50%", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 32, marginBottom: 12, boxShadow: `0 0 24px ${G.accent}40` }}>
          ⚡
        </div>
        <div style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 18, fontWeight: 900 }}>{profile.name || "User"}</div>
        <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 12, marginTop: 4 }}>{userData?.phoneNumber || "+91 XXXXXXXXXX"}</div>
        <div style={{ display: "flex", gap: 6, justifyContent: "center", marginTop: 10 }}>
          <Badge>{profile.qualification || "Learner"}</Badge>
          <Badge color={G.blue}>{profile.specialization || "General"}</Badge>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "center", marginTop: 16 }}>
          {[["Level 3", G.accent], ["74% Avg", G.green], ["5 Streak🔥", "#F97316"]].map(([v, c]) => (
            <div key={v} style={{ background: G.card, border: `1px solid ${G.border}`, borderRadius: 8, padding: "8px 12px" }}>
              <div style={{ color: c, fontFamily: "monospace", fontSize: 12, fontWeight: 700 }}>{v}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: 16 }}>
        {/* Profile Info */}
        <Card style={{ marginBottom: 16 }}>
          <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10, letterSpacing: 1, marginBottom: 12 }}>PROFILE DETAILS</div>
          {[["Name", profile.name], ["Age", profile.age], ["Experience", profile.experience], ["Qualification", profile.qualification]].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${G.border}` }}>
              <span style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 12 }}>{k}</span>
              <span style={{ color: G.textPrimary, fontFamily: "monospace", fontSize: 12, fontWeight: 700 }}>{v || "—"}</span>
            </div>
          ))}
        </Card>

        {/* Settings */}
        <Card style={{ marginBottom: 16 }}>
          <div style={{ color: G.textMuted, fontFamily: "monospace", fontSize: 10, letterSpacing: 1, marginBottom: 12 }}>SETTINGS</div>
          {[["Push Notifications", notif, setNotif], ["Dark Mode", darkMode, setDarkMode]].map(([label, val, setter]) => (
            <div key={label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0", borderBottom: `1px solid ${G.border}` }}>
              <span style={{ color: G.textSecondary, fontFamily: "monospace", fontSize: 13 }}>{label}</span>
              <Toggle val={val} onChange={setter} />
            </div>
          ))}
        </Card>

        {/* Schema Reference */}
        <Card style={{ marginBottom: 16, border: `1px solid ${G.blue}30`, background: `${G.blue}08` }}>
          <div style={{ color: G.blue, fontFamily: "monospace", fontSize: 10, letterSpacing: 1, marginBottom: 10 }}>FIRESTORE SCHEMA REFERENCE</div>
          <pre style={{ color: G.textSecondary, fontFamily: "monospace", fontSize: 10, lineHeight: 1.6, overflow: "auto", whiteSpace: "pre-wrap" }}>{`users/{uid}
  ├─ name, age, phone
  ├─ qualification, experience
  ├─ totalXP, level, streak
  └─ testResults[] (subcollection)
       ├─ moduleId, score
       ├─ total, pct, pass
       └─ timestamp

studyMaterials/{moduleId}
  ├─ title, description, icon
  ├─ topics: [{id, title, duration}]
  └─ pdfUrl, articleContent

quizzes/{moduleId}
  └─ questions: [{
       question, options[4],
       correctIndex, explanation
     }]`}</pre>
        </Card>

        <Btn variant="danger" onClick={onLogout}>Sign Out</Btn>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   APP ROOT
───────────────────────────────────────────── */
export default function App() {
  const [screen, setScreen] = useState("otp"); // otp | profile | main
  const [userData, setUserData] = useState(null);
  const [activeTab, setActiveTab] = useState("home");

  const handleLogin = (user) => {
    setUserData(user);
    setScreen("profile");
  };

  const handleProfileComplete = (user) => {
    setUserData(user);
    setScreen("main");
  };

  const handleLogout = () => {
    setUserData(null);
    setScreen("otp");
    try { auth.signOut(); } catch (e) { }
  };

  if (screen === "otp") return <OTPScreen onLogin={handleLogin} />;
  if (screen === "profile") return <ProfileSetup user={userData} onComplete={handleProfileComplete} />;

  const tabContent = {
    home: <Dashboard userData={userData} onNav={setActiveTab} />,
    study: <StudyHub />,
    tests: <TestScreen userData={userData} />,
    progress: <ProgressScreen />,
    profile: <ProfileScreen userData={userData} onLogout={handleLogout} />,
  };

  return (
    <div style={{ maxWidth: 480, margin: "0 auto", background: G.bg, minHeight: "100vh", position: "relative", fontFamily: "monospace" }}>
      <CircuitBg />
      <div style={{ position: "relative", zIndex: 1 }}>
        {tabContent[activeTab]}
        <BottomNav active={activeTab} onChange={setActiveTab} />
      </div>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: ${G.bg}; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: ${G.surface}; }
        ::-webkit-scrollbar-thumb { background: ${G.border}; border-radius: 4px; }
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
